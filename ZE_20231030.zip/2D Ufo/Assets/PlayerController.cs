﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PlayerController : MonoBehaviour
{
    public Text winText;
    public Text countText;
    public int count=0 ;
    private Rigidbody2D rbd;
    public float speed;

    // Start is called before the first frame update
    void Start()
    {
        rbd = GetComponent<Rigidbody2D>();        

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector2 movement = new Vector2(moveHorizontal, moveVertical);
        rbd.AddForce(movement*speed  );


    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag=="PickUp")
        {
            other.gameObject.SetActive(false);
            count++;
            SetCountText();

            
        }
    }

    void SetCountText()
    {
        countText.text = "Score :" + count.ToString();
        if (count==8)
        {
            winText.text = "You Win!";
        }


    }
}
